<!-- Laporan -->
	<h2 class="tit"><i class="fa fa-print"></i>&nbsp;Laporan</h2>
	<hr class="bord" />

	<ol class="lap">
		<li><a href="print/print-anggota.php" target="_blank"><i class="fa fa-group"></i>&nbsp;Anggota</a></li>
		<li><a href="print/print-buku.php" target="_blank"><i class="fa fa-book"></i>&nbsp;Buku</a></li>
		<li><a href="print/print-transaksi.php" target="_blank"><i class="fa fa-plus-square"></i>&nbsp;Transaksi</a></li>
	</ol>