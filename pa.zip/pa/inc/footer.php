</div>
		<div class="clearfix"></div>
	</div>
<!-- Footer -->
	<div class="footer">
		<p>&copy; Copyright by Reno <?php echo date('Y'); ?></p>
	</div>
</body>
</html>